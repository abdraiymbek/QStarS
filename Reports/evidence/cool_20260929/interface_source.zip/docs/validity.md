# Validity domain and release limitations

**This is not validated general-purpose QStarS v1.** Current time-dependent
results concern smooth, Newtonian, fixed-excision envelopes with fixed
composition and explicitly chosen outer boundary conditions. Some hot
pressure-confined models have quantitative convergence evidence. They are
not complete quasi-star evolutionary tracks.

Report 14 adds explicit ideal H−/H/He material energy and population partial
derivatives, but **does not certify a cool non-LTE material/radiation closure**.
The tested cool transfer states fail nonlinear and energy gates. H0 plus
Rayleigh scattering is rejected unless the native executable has the verified
HI-selection/stride/Jacobian repair. Nonfinite native diagnostics invalidate a
run even if its last reported correction is zero. Frozen-population derivatives
are not a relaxed EOS, and cannot be used to infer the physical sonic condition.
The [cool contract](nlte_cool_closure.md) records unresolved level-dissolution,
rate-data, shared energy-gauge and convective-handoff requirements.

## Active checks

| Check | Threshold and purpose |
|---|---|
| Mass and energy ledger | Default residual limit 1e-7 of initial mass/internal energy; validation additionally reports binding-energy and throughput normalizations |
| Radial motion | Configured maximum Mach 0.2; the run stops within 0.01% of that boundary to avoid endless bisection masquerading as a solver failure |
| Newtonian gravity | Maximum compactness 2GM/(rc²) = 0.001 by default |
| Ideal EOS | T=1e5..1e8 K, H and He ionization screening >=99%, electron occupation <=0.1 |
| MESA interface | H1/He4 only; reject neutral ideal backstop, nonfinite values, unsupported query coordinates and first-law defect >1% |
| MESA dilute gas pressure | Reject >1% discrepancy from rho kT/(mu m_u) when T>=40000 K, eta<-10 and conservative Coulomb Gamma<0.01; radiation must not hide gas-pressure error |
| Omitted conduction | Reject conductive contribution >1% of diffusive heat transport |
| Radiative diffusion | Radiation-gradient Knudsen number <=0.1 and flux below free streaming; outer flux is checked separately |
| Efficient convection | Pe>=100 on faces carrying >1% of the transported flux in convection; no supersonic blobs |
| Geometry | Positive ordered faces and volumes; independent geometry/volume agreement within 1e-8 |
| Boundary replacement | <=10% of the affected cell per substep; retries preserve the accepted ledger |
| Nonlinear solve | Recomputed momentum, energy and transport residuals; no energy residual reset |
| Restart | Versioned, finite physical arrays, complete finite ledger, mesh/volume consistency and stored solver state |

Kn=0.1 and Pe=100 are conservative asymptotic screening choices: diffusion
and lossless convection need scale separation. They do not establish LTE
thermalization, a realistic photosphere or one-percent evolutionary accuracy.
Cell optical depth is saved but no longer used as a rejection rule: refining
a smooth diffusive field must not make its physical validity disappear.

The default conservation limit is an execution safeguard. Passing it is not
a sufficient research accuracy criterion, especially when transported energy
is tiny relative to stored radiation energy. Reports retain all three energy
normalizations and require convergence of interior profiles.

## Limits that invalidate a general v1 claim

- A moving cavity is absent. Mesh redistribution conserves resolved-domain
  mass and energy but does not create the missing physical cavity reservoir.
- A validated coupled production atmosphere and full radiatively lossy convection are absent.
  Effective temperature from luminosity and outer radius is a diagnostic;
  the envelope solver has no validated photospheric radius.
  Native full MLT and explicit-pressure atmosphere references now execute,
  but the 6000 K candidate requires Mach 2.34 convection and the 8000 K
  candidate is geometrically extended. Numerical convergence does not make
  those assumptions physical; [Report 8](../Reports/Report_8.md) records the
  specific release blocker and its sensitivity tests.
- The wind ODE component is not coupled to the envelope. A prescribed wind or
  launch formula does not prove an escaping transonic solution exists.
- MESA EOS blending has retained first-law counterexamples. Rejecting them
  is necessary, but it leaves holes in the usable thermodynamic domain.
- The nuclear/composition evolution, stellar backend and several full
  published quasi-star evolutionary tracks remain unvalidated.
- No cross-paper evolutionary predictive test without retuning has passed.

These requirements are scientifically meaningful in 1D and cannot be waived
merely because implementation is difficult. In contrast, rotation, discs,
magnetic geometry and simultaneous angular inflow/outflow are unresolved by
this spherical model. Its effective streams must never be represented as a
resolved multidimensional solution. Full GR/ADM-mass accounting is also
outside the documented Newtonian convention.

`model_domain_exit`, `numerical_failure`, `control_stop` and
`completed_requested_interval` have distinct meanings. None establishes
physical destruction, instability or a quasi-star lifetime. QSRD remains
blocked by the independent framework-validation prerequisite.

## Spherical diffusion wind component (Report 9)

The new component retains gas pressure and ionization through the gas sonic
point, and stops at a diffusion validity boundary or a second sonic approach.
Its no-convection assumption is not validated at every subsonic matching point.
The component can have decreasing entropy there; no stability claim follows.
A paper-photosphere diagnostic extends past the strict diffusion screen and
must not be attached as a production boundary. Rosseland mean opacity does
not supply a non-LTE flux mean or gas/radiation thermalization rate.

The point-mass wind is screened at shell mass / central mass < 1%; its spherical
hydrostatic reference can include self-gravity. Numerical root failures and
local inadmissible critical states are not global proofs of nonexistence.
FreeEOS and supplied base energy must use one energy zero. The fixed-sphere
flux interface still needs a conservative moving-face evolution update.
See [the full validity boundary](spherical_wind.md) and [Report 9](../Reports/Report_9.md).

## Report 10 enforcement

`integrate_atmosphere` now terminates on an accepted convective-Mach-one
event and raises `AtmosphereDomainExit` with structured diagnostics. The
sound speed is the local adiabatic EOS sound speed. Supersonic MLT is neither
clipped nor returned as a valid profile. Earlier archived continuations are
invalid diagnostics. This rejection policy does not validate a zero-convection
wind base or an unresolved turbulent state.

The historical-opacity reference rejects states outside its explicit common
table rectangle and verifies pure OPAL/AF94 fractions on each call. It returns
only a Rosseland mean, not a flux mean for escaping radiation. The strict wind
still stops at R_E=0.1. `paper_photosphere` is solely a comparison continuation;
its R_E=0.75 endpoint must not be exported as a validated stellar photosphere.
Overall outcome: **OUTER FAIL**; coupled Stage B and QSRD remain gated.

## Escaping radiation component (Report 11)

Grey angular transfer now has independent published-moment, diffusion, streaming,
frame-transformation, conservation and refinement evidence. It is limited to a
specified frequency-independent isotropic scattering law; moving VEF validation
covers outward v/c<=0.01. This does not certify MESA Rosseland means as escaping
flux means, LTE in a dilute gas, or a non-LTE population solution.

The continuum wind control has no gas-pressure or material-energy equation and
uses supplied mdot/base speed. It cannot match the envelope's entropy/enthalpy
or supply a sonic eigenvalue. Its optional 100-Msun scaling fails a physical
fully-ionized/self-gravity interpretation and is labeled only a mathematical
scaling. The 100R exterior failed radiation-profile and photospheric convergence;
only the extended control has the documented 0.2% placement evidence. The
Mach-one MLT exit remains unchanged. See [Report 11](../Reports/Report_11.md).

## Report 12 self-selection boundary

The production self-selected outer gate remains **FAIL**. Frequency-band thermal transfer, a base-selected adiabatic wind and conservative arbitrary-moment interface are separately verified components. They have not been joined into a population-consistent, recombining, convectively matched, escaping quasi-star solution. The static transfer solves different gas/radiation temperatures with frozen synthetic absorption/scattering; it is not a non-LTE atom. The adiabatic wind has no radiation. Its analytically justified hydrostatic/no-wind outcome applies only to that declared reference family. No numerical matching failure is promoted to physical nonexistence. [Report 12 equations and restrictions](self_selected_outer.md) state the conditions needed before a physical envelope test or coupled evolution.

## Non-LTE interface boundary (Report 13)

A native CMFGEN calculation and QStarS adapter now execute on Apple Silicon.
This does not expand the certified physical envelope/wind domain. A successful
process, close reference spectrum, conserved nuclei, or a small population
correction alone cannot certify the thermal or global radiation-energy budget.
Read-only export invariance and radiation quadrature tests apply only to their
stated component cases.

The exercised H/He material is hot and almost ionized, with prescribed velocity
and mass loss. Cold quasi-star recombination, H−/molecules where important,
level-dissolution energy consistency, population advection, non-LTE derivatives
and the FreeEOS energy-gauge/composition bridge remain unvalidated. Inelastic
scattering exchange is not supported by the diagnostic ABI. The current local
wind critical formula does not include the full nonlocal CMF force response.
The production entry point refuses coupling. Supersonic MLT, physical wind
selection, coupled evolution and QSRD gates are unchanged. See
[the exact interface contract](nlte_backend.md).
