"""Ball thesis 2.15-2.16 surface: outer face at tau = 2/3 with no mass above it.

L* = 4 pi R*^2 sigma Teff^4 (2.15). The photospheric gas pressure is
P_g = (2 g/3 kappa_ph)(1 - L*/L_Edd), L_Edd = 4 pi G c M*/kappa_ph (2.16),
which equals 2 g/(3 kappa_ph) - a Teff^4/6: the gas pressure at tau = 2/3 of
a constant-kappa Eddington grey atmosphere, T^4 = 3/4 Teff^4 (tau + 2/3),
dP/dtau = g/kappa. kappa_ph = kappa(rho_ph, Teff) with rho_ph an implicit
unknown. The outer face feels P_ph = P_g + a Teff^4/3. Gamma_ph >= 1
(P_g <= 0) is a model domain exit and is never clipped.
"""
import numpy as np
from .constants import A,C,G,PI,SIGMA
from .mass_transport import DomainError

def effective_temperature(luminosity,radius):
    return (luminosity/(4*PI*radius**2*SIGMA))**.25

def eddington_factor(luminosity,mass,kappa):
    """Gamma_ph = L*/L_Edd with L_Edd = 4 pi G c M*/kappa_ph."""
    return kappa*luminosity/(4*PI*G*C*mass)

def gas_pressure(gravity,kappa,teff):
    """Thesis 2.16: (2 g/3 kappa)(1 - Gamma) = 2 g/(3 kappa) - a Teff^4/6."""
    return 2*gravity/(3*kappa)-A*teff**4/6

def external_pressure(pg,teff):
    """Total pressure on the outer face: P_g + a Teff^4/3 (T = Teff at tau = 2/3)."""
    return pg+A*teff**4/3

def implied_column(radius,pressure,gravity):
    """Mass a hydrostatic atmosphere above the face would need, 4 pi R^2 P_ph/g (diagnostic N4)."""
    return 4*PI*radius**2*pressure/gravity

def evaluate(rho_ph,luminosity,radius,mass,eos,opacity):
    """Row (f) and the photospheric state at a trial (rho_ph, L_N, R, M_N); complex-step safe.

    residual = [P_g,EOS(rho_ph, Teff) - (2 g/3 kappa_ph - a Teff^4/6)]/(2 g/3 kappa_ph).
    Raises DomainError when the target gas pressure is not positive.
    """
    teff=effective_temperature(luminosity,radius)
    rho=np.atleast_1d(rho_ph);T=np.atleast_1d(teff)
    q=eos.evaluate(rho,T);kappa=np.atleast_1d(opacity(rho,T))[0]
    gravity=G*mass/radius**2
    scale=2*gravity/(3*kappa)
    target=scale-A*teff**4/6
    if not np.real(target)>0:
        raise DomainError('Photospheric gas pressure is not positive (Gamma_ph >= 1); no Ball surface exists')
    pg=q['pg'][0]
    return dict(residual=(pg-target)/scale,teff=teff,kappa=kappa,gravity=gravity,gas_pressure=pg,
                target=target,pressure=external_pressure(pg,teff),
                eddington_factor=eddington_factor(luminosity,mass,kappa))

def solve(luminosity,radius,mass,eos,opacity,guess=None,tolerance=1e-14,max_iterations=200):
    """rho_ph of row (f) for given L*, R*, M*: safeguarded Newton in ln rho on a bracket.

    The residual increases with rho wherever kappa does not fall faster than
    1/P_g; a sign change is bracketed first, so a non-monotone opacity can
    only select a root, never a non-root.
    """
    def f(lnrho):
        x=complex(lnrho,1e-30)
        out=evaluate(np.exp(x),luminosity,radius,mass,eos,opacity)
        return float(out['residual'].real),float(out['residual'].imag/1e-30)
    teff=float(effective_temperature(luminosity,radius))
    x=float(np.log(1e-12 if guess is None else guess))
    fx,_=f(x)
    lo=hi=x;flo=fhi=fx
    for sign in (-1,1):
        step=.5
        while (flo>0 if sign<0 else fhi<0) and step<64:
            trial=(lo if sign<0 else hi)+sign*step;step*=2
            try:value,_=f(trial)
            except ValueError:break  # EOS or opacity domain edge: no root beyond it
            if sign<0:lo,flo=trial,value
            else:hi,fhi=trial,value
    if not (flo<=0<=fhi):raise DomainError('Photospheric density not bracketed inside the microphysics domain')
    x=lo if abs(flo)<abs(fhi) else hi
    for _ in range(max_iterations):
        fx,dfx=f(x)
        if abs(fx)<=tolerance:return float(np.exp(x))
        if fx<0:lo=x
        else:hi=x
        trial=x-fx/dfx if dfx>0 else .5*(lo+hi)
        x=trial if lo<trial<hi else .5*(lo+hi)
        if hi-lo<=1e-15*max(1.,abs(x)):return float(np.exp(x))
    raise RuntimeError(f'Photospheric density solve failed at Teff={teff:g} K')
